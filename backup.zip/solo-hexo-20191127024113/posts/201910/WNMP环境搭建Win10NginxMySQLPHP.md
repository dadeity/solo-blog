title: WNMP环境搭建（Win10+Nginx+MySQL+PHP）
date: '2019-10-31 14:10:54'
updated: '2019-10-31 14:45:37'
tags: [MySQL, Nginx, PHP, Win10]
permalink: /articles/2019/10/31/1572502254745.html
---
![](https://img.hacpai.com/bing/20190526.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)

## 准备工作
- 官网下载 Nginx、MySQL、PHP到本地（根据自己需求选择版本）
	PHP下载地址：[https://windows.php.net/downloads/releases/](https://windows.php.net/downloads/releases/)
	Nginx下载地址：[http://nginx.org/en/download.html](http://nginx.org/en/download.html)
	MySQL下载地址：[https://dev.mysql.com/downloads/mysql/](https://dev.mysql.com/downloads/mysql/)
![微信截图20191030152917.png](https://img.hacpai.com/file/2019/10/微信截图20191030152917-d182a0d0.png)

- 将下载好的压缩包解压到D:/wnmp目录下，我没有重命名解压的文件名称，是为了后期可以清楚的知道每个软件的版本。
![微信截图20191030153408.png](https://img.hacpai.com/file/2019/10/微信截图20191030153408-a4f0fe91.png)

发现wnmp文件夹下面有个www目录， 这个用来放运行的项目的，为了避免更新删除Nginx导致项目丢失，悲剧发生，最好将他独立出来。
## 安装Nginx
- 打开`D:\wnmp\nginx-1.17.4\conf\nginx.conf`配置文件，修改如下（特别关注下面 `#注意`代码块）

```powershell

#user  nobody;
worker_processes  1;
# 注意: 开启错误日志
error_log  logs/error.log;
error_log  logs/error.log  notice;
error_log  logs/error.log  info;

pid        logs/nginx.pid;


events {
    worker_connections  1024;
}


http {
    include       mime.types;
    default_type  application/octet-stream;

    sendfile        on;
    #tcp_nopush     on;

    #keepalive_timeout  0;
    keepalive_timeout  65;

    #gzip  on;

    server {
        listen       80;
        server_name  localhost;

        charset utf-8;

        #access_log  logs/host.access.log  main;

		# 注意 在下面解析PHP里面用到的$document_root 就是指的这个目录
        root "D:/wnmp/www";
        index index.html index.htm index.php;

        location / {
            try_files $uri $uri/ /index.php?$query_string;
            autoindex on;
            autoindex_exact_size off;
            autoindex_localtime on;
        }

        error_page   500 502 503 504  /50x.html;
        location = /50x.html {
            root   html;
        }
		# 注意 配置解析PHP
        location ~ \.php(.*)$ {
            fastcgi_pass   127.0.0.1:9000;
            fastcgi_index  index.php;
            fastcgi_split_path_info  ^((?U).+\.php)(/?.+)$;
            fastcgi_param  SCRIPT_FILENAME  $document_root$fastcgi_script_name;
            fastcgi_param  PATH_INFO  $fastcgi_path_info;
            fastcgi_param  PATH_TRANSLATED  $document_root$fastcgi_path_info;
            include        fastcgi_params;
        }

        # 注意：用于后期多项目配置虚拟域名
        include vhost/*.conf;
    }
}


```
- 在`D:\wnmp\nginx-1.17.4\conf`目录下面新建vhost文件夹
![微信截图20191030155209.png](https://img.hacpai.com/file/2019/10/微信截图20191030155209-e085867c.png)

## 安装PHP
- 将php.exe所在目录添加系统环境变量PATH，方便全局使用php命令
![微信截图20191030160534.png](https://img.hacpai.com/file/2019/10/微信截图20191030160534-5123a8e2.png)

- 复制php.ini-development重命名为php.ini，修改php.ini中的`extension_dir`路径，需要开启那些扩展根据实际情况。
```powershell
; On windows:
extension_dir = "D:\wnmp\php-7.2.23-nts-Win32-VC15-x64\ext"
date.timezone = Asia/Shanghai
enable_dl = On
cgi.force_redirect = 0
fastcgi.impersonate = 1
cgi.rfc2616_headers = 1
```
## PHP关联Nginx
- 下载`RunHiddenConsole.exe`到`D:\wnmp\nginx-1.17.4`目录下
RunHiddenConsole.exe下载地址：[https://pan.baidu.com/s/1Val2Tlm9joSFf8FKMAwD3Q](https://pan.baidu.com/s/1Val2Tlm9joSFf8FKMAwD3Q)
![微信截图20191030165907.png](https://img.hacpai.com/file/2019/10/微信截图20191030165907-52ac094e.png)

- 在`D:\wnmp\nginx-1.17.4`目录下创建start.bat文件，内容如下

```powershell
@echo off
set PHP_HOME=D:/wnmp/php-7.2.23-nts-Win32-VC15-x64
set NGINX_HOME=D:/wnmp/nginx-1.17.4

REM Windows 下无效
REM set PHP_FCGI_CHILDREN=5

REM 每个进程处理的最大请求数，或设置为 Windows 环境变量
set PHP_FCGI_MAX_REQUESTS=1000

taskkill /F /IM php-cgi.exe > nul
echo Starting PHP FastCGI...
RunHiddenConsole %PHP_HOME%/php-cgi.exe -b 127.0.0.1:9000 -c %PHP_HOME%/php.ini

taskkill /F /IM nginx.exe > nul
echo Starting nginx...
RunHiddenConsole %NGINX_HOME%/nginx.exe
```
- 在`D:\wnmp\nginx-1.17.4`目录下创建stop.bat文件，内容如下

```powershell
@echo off
echo Stopping nginx...  
taskkill /F /IM nginx.exe > nul
echo Stoped nginx

echo Stopping PHP FastCGI...
taskkill /F /IM php-cgi.exe > nul
echo Stoped FastCGI
exit
```
- 在`D:\wnmp\www` 目录下面新建index.php文件，增加`phpinfo();`，测试PHP和Nginx是否关联成功
![微信截图20191031105038.png](https://img.hacpai.com/file/2019/10/微信截图20191031105038-6527e532.png)

## 安装MySQL
- 在`D:\wnmp\mysql-5.7.27-winx64`目录下面创建mysql.ini文件（注：mysql5.7.18之后的版本没有my.ini文件需要手动创建），添加如下内容

```powershell
[client]
port=3306
[mysql]
default-character-set=utf8
[mysqld]
# 端口号
port=3306
# 安装路径
basedir="D:/wnmp/mysql-5.7.27-winx64"
# 数据存放路径
# mysql数据没有放到mysql子目录的原因，避免以后升级、卸载mysql导致数据丢失
datadir="D:/wnmp/mysqldata"
# 默认字符集
character-set-server=utf8
# 默认存储引擎
default-storage-engine=INNODB
```
- 进入`D:\wnmp\mysql-5.7.27-winx64\bin`目录下，打开终端注册MySQL服务

```bash
mysqld -install 
```
- 进入`D:\wnmp\mysql-5.7.27-winx64\bin`目录下，初始化MySQL
```bash
mysqld --initialize
```
- 进入`D:\wnmp\mysql-5.7.27-winx64\bin`目录下，启动MySQL

```bash
# 启动
net start mysql
# 停止
net stop mysql
```
- `D:\wnmp\mysqldata`目录下，打开 **.err** 文件，复制：root@localhost:后的密码(随机密码，每次安装不一样)
![微信截图20191031121951.png](https://img.hacpai.com/file/2019/10/微信截图20191031121951-3d91afe1.png)

- 使用刚才复制的密码登录MySQL

```bash
# 登录MySQL
D:\wnmp\mysql-5.7.27-winx64\bin>mysql -u root -p
# 输入刚才复制的密码
Enter password: ************
Welcome to the MySQL monitor.  Commands end with ; or \g.
Your MySQL connection id is 3
Server version: 5.7.27

Copyright (c) 2000, 2019, Oracle and/or its affiliates. All rights reserved.

Oracle is a registered trademark of Oracle Corporation and/or its
affiliates. Other names may be trademarks of their respective
owners.

Type 'help;' or '\h' for help. Type '\c' to clear the current input statement.
mysql> 
```
- 修改MySQL登录密码

```sql
ALTER USER 'root'@'localhost' IDENTIFIED BY 'mysql';
```
- 开启root用户远程连接（任意IP都可以访问）

```sql
UPDATE mysql.user SET Host = '%' WHERE User = 'root';
```

- 最后刷新MySQL的系统权限相关表

```sql
flush privileges;
```
此刻，可以用Navicat连接MySQL了，网络没有问题的情况下，其他机器也可以远程访问你的MySQL

最后 WNMP环境搭建（Win10+Nginx+MySQL+PHP）完成了 。

## 一键启动、关闭（MySQL，Nginx，PHP） bat
- 下载地址：[https://pan.baidu.com/s/1NPWFuPKEZ2Sd3Qjzr1Qh1w](https://pan.baidu.com/s/1NPWFuPKEZ2Sd3Qjzr1Qh1w)
