title: Failed to initialize component [org.apache.catalina.webresources.JarResource
  解决
date: '2019-11-26 10:05:26'
updated: '2019-11-26 10:05:26'
tags: [Java, IDEA, Win10, Maven]
permalink: /articles/2019/11/26/1574733926071.html
---
![](https://img.hacpai.com/bing/20191031.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)

# 环境配置
- JDK1.8
- Win10
# 问题描述
今天使用Spring配置完之后， 运行测试提示 ：
`Failed to initialize component [org.apache.catalina.webresources.JarResource`
# 解决办法
1. 找到本地仓库位置，一般在`C:\Users\Admin\.m2\repository`
![微信截图20191126095658.png](https://img.hacpai.com/file/2019/11/微信截图20191126095658-cdec5e44.png)
2. 删除**repository**目录下面所有文件夹
3. pom里面加个空行让他重新下载或者在idea中点击下图红色箭头所指按钮
![微信截图20191126100101.png](https://img.hacpai.com/file/2019/11/微信截图20191126100101-fa9a7ece.png)


