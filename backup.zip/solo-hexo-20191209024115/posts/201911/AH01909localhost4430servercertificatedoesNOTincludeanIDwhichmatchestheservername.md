title: 'AH01909: localhost:443:0 server certificate does NOT include an ID which matches
  the server name'
date: '2019-11-11 17:24:01'
updated: '2019-11-11 17:24:01'
tags: [Apache]
permalink: /articles/2019/11/11/1573464240955.html
---
![](https://img.hacpai.com/bing/20190619.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)

# 配置
- 服务器：Apache2.4
# 原因
Apache开启**mod_ssl.so**模块，需要禁用
# 解决办法
- 打开httpd.conf 文件，找到`LoadModule ssl_module modules/mod_ssl.so`所在行，在最前面加 **#**号将其注释
```
#LoadModule ssl_module modules/mod_ssl.so
```

