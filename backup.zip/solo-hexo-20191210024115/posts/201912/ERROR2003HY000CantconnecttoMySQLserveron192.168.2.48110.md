title: 'ERROR 2003 (HY000): Can''t connect to MySQL server on ''192.168.2.48'' (110)'
date: '2019-12-09 10:14:37'
updated: '2019-12-09 10:14:37'
tags: [MySQL]
permalink: /articles/2019/12/09/1575857676988.html
---
![](https://img.hacpai.com/bing/20181101.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)

# 问题描述
今天使用另一台机器连接本地MySQL时候提示：
```javascript
ERROR 2003 (HY000): Can't connect to MySQL server on '192.168.2.48' (110)
```
# 问题分析
- 网上说，你的MySQL设置了`bind_address=127.0.0.1`，不允许远程登录。
- 我一想不对啊，前几天还可以登录的 ，肯定不是这个原因，查看 my.cnf 或者my.ini 并没有设置。
- 最后我觉得是防火墙把请求给屏蔽了。
# 解决办法
- 关闭防火墙
- 问题解决，远程连接MySQL成功。
