title: 'Application Server was not connected before run configuration stop, reason:
  Unable to ping…解决办法'
date: '2019-12-03 13:55:05'
updated: '2019-12-03 13:55:05'
tags: [Java, Tomcat, JDK, Win10]
permalink: /articles/2019/12/03/1575352505017.html
---
![](https://img.hacpai.com/bing/20191120.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)

## 环境配置
- window10
- jdk-7u80
- apache-tomcat-9.0.11

## 问题描述
今天通过idea 运行java项目提示：

```bash
Application Server was not connected before run configuration stop, reason:Unable to ping server at localhost:1099
```
## 问题原因
- **jdk版本tomcat版本不匹配**，重要！重要！重要！
- 通过[官网的这张图](http://tomcat.apache.org/whichversion.html)，可以清楚的了解jdk与tomcat对应版本
![微信截图20191203134750.png](https://img.hacpai.com/file/2019/12/微信截图20191203134750-d9133857.png)

## 解决办法（二选一）
知道了问题的原因，那解决办法就是轻松加愉快了！

- **JDK1.7** 升级 **JDK1.8**
- **Tomcat-9.x** 降级 **Tomcat-8.x**
