title: Linux 设置定时重启
date: '2019-10-29 18:06:41'
updated: '2019-10-29 18:06:41'
tags: [Linux]
permalink: /articles/2019/10/29/1572343601696.html
---
![](https://img.hacpai.com/bing/20190223.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)

# 准备工作
- 如果不太清楚当前的Linux系统是否支持crontab，就执行如下命令
```
yum install crontab
```
- 执行如下命令，查看当前的已经存在的定时任务
```
crontab -l
```
如果提示：no crontab for root，说明没有定时任务
# 添加定时重启任务
- 执行 crontab -e 命令添加
```
# 每天凌晨2点30进行重启
30 02 * * * /sbin/reboot 
```
- crontab 格式说明：
![20190530145732532.png](https://img.hacpai.com/file/2019/10/20190530145732532-8065b5c9.png)

- 重启 crontab
```
systemctl restart crond
```
