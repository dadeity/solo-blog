title: Git 提交代码到远程仓库5步
date: '2019-10-29 15:48:11'
updated: '2019-10-29 15:48:11'
tags: [Git]
permalink: /articles/2019/10/29/1572335291416.html
---
![](https://img.hacpai.com/bing/20171230.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)

## 准备工作
- 安装 Git
- 配置Git

```
# 局部配置 [在项目下面]
git config user.name "远程仓库用户名（如：github用户名）"
git config user.email "远程仓库绑定邮箱"

# 全局配置
git config --global user.name "远程仓库用户名（如：github用户名）"
git config --global user.email "远程仓库绑定邮箱"
```

## 具体操作步骤
- 初始化版本库
```
git init 
```
- 添加文件到版本库（只是添加到缓存区），.代表添加文件夹下所有文件 
```
git add .
```
- 把添加的文件提交到版本库，并填写提交备注

```
git commit -m "first commit"  
```
- 把本地库与远程库关联

```
git remote add origin 你的远程库地址 
```
- 第一次推送时需要加-u，以后提交就不需要
**注意：回车之后需要输入你的远程仓库用户名和密码**
```
git push -u origin master 
```
