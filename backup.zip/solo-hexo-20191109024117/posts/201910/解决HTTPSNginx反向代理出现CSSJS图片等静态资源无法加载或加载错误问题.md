title: 解决HTTPS Nginx反向代理出现CSS/JS/图片等静态资源无法加载或加载错误问题
date: '2019-10-29 11:22:13'
updated: '2019-10-29 11:28:05'
tags: [后端, Nginx, HTTPS]
permalink: /articles/2019/10/29/1572319332997.html
---
![](https://img.hacpai.com/bing/20180809.jpg?imageView2/1/w/960/h/540/interlace/1/q/100) 

## 问题描述
- 今天配置了HTTPS 和 Nginx 反代理出现 部分 JS 无法加载问题
![微信截图20191029111137.png](https://img.hacpai.com/file/2019/10/微信截图20191029111137-7442b238.png)
## 解决办法
- 在配置反代理xxx.conf 文件中 ```location / { }``` 添加如下代码
```
location / {

    proxy_pass http://127.0.0.1:8080;

     
    # 需要添加的代码
    proxy_set_header X-Real-IP $remote_addr;

    proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;

    proxy_set_header Host $host;

    proxy_set_header Upgrade-Insecure-Requests 1;

    proxy_set_header X-Forwarded-Proto https;

}
```
