title: Linux 使用文件创建内存交换文件
date: '2019-10-29 14:19:10'
updated: '2019-10-29 14:19:10'
tags: [Linux, swap]
permalink: /articles/2019/10/29/1572329950650.html
---
![](https://img.hacpai.com/bing/20181019.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)

## 场景
- 针对服务器或者工作站这些常年运行的系统来说，创建内存交换分区是很有必要的！
- 例如：我的个人博客使用的是 阿里云CentOS7 1核1G带宽1M服务器，突然发现内存快消耗殆尽了
![在这里插入图片描述](https://img-blog.csdnimg.cn/20191029135854310.png)
- 对于上面的问题，解决办法有：升级服务器配置，设置内存交换分区
## 使用文件创建内存交换文件
为什么说是内存交换文件，而不是交换分区。因为在物理分区无法支持的环境下，可以使用 dd去创建一个 大文件，作为内存交换文件。这样可以省去分区的操作，操作更加简单。多说无益，开始操作吧

- 使用dd命令在 /tmp目录下新增一个 2048MB的文件

```powershell
dd if=/dev/zero of=/tmp/swap bs=1M count=2048
```
- 使用 mkswap 将 /tmp/swap 文件格式化为内存交换文件格式

```powershell
mkswap /tmp/swap
```
- 使用swapon 将 /tmp/swap启动，

```powershell
swapon /tmp/swap

```
- 可以使用 swapoff 将 /tmp/swap关闭

```powershell
swapoff /tmp/swap
```
- 设置自启动，使用vim在/etc/fstab 文件中添加如下内容

```powershell
# 为何这里不要使用UUID?这是因为系统仅会查询区块设备（block device）不会查文件
# 所有，这里千万不用使用UUID
/tmp/swap       swap    swap    defaults        0       0
```
![在这里插入图片描述](https://img-blog.csdnimg.cn/20191029141539704.png?x-oss-process=image/watermark,type_ZmFuZ3poZW5naGVpdGk,shadow_10,text_aHR0cHM6Ly9ibG9nLmNzZG4ubmV0L2dpdGh1Yl8zODMzNjkyNA==,size_16,color_FFFFFF,t_70)

