title: WAMP环境搭建（Win10+Apache+MySQL+PHP）
date: '2019-11-04 10:55:12'
updated: '2019-11-06 16:36:29'
tags: [Win10, PHP, MySQL, Apache]
permalink: /articles/2019/11/04/1572836112534.html
---
![](https://img.hacpai.com/bing/20190115.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)

## 准备工作
- 官网下载 Nginx、MySQL、PHP到本地（根据自己需求选择版本）
	PHP下载地址：[https://windows.php.net/downloads/releases/](https://windows.php.net/downloads/releases/)
	Apache下载地址：[https://www.apachehaus.com/cgi-bin/download.plx#APACHE24VC15](https://www.apachehaus.com/cgi-bin/download.plx#APACHE24VC15)
	MySQL下载地址：[https://dev.mysql.com/downloads/mysql/](https://dev.mysql.com/downloads/mysql/)
![微信截图20191104100330.png](https://img.hacpai.com/file/2019/11/微信截图20191104100330-d6798a86.png)


- 将下载好的压缩包解压到D:/wamp目录下，我没有重命名解压的文件名称，是为了后期可以清楚的知道每个软件的版本。
![微信截图20191104101229.png](https://img.hacpai.com/file/2019/11/微信截图20191104101229-ce49fe58.png)


发现wamp文件夹下面有个www目录， 这个用来放运行的项目的，为了避免更新删除Nginx导致项目丢失，悲剧发生，最好将他独立出来。
## 安装Apache
- 打开`D:\wamp\Apache24\conf\httpd.conf`配置文件，修改如下（特别关注下面 `#注意`代码块）

```bash
# 设置Apache程序根目录
Define SRVROOT "D:/wamp/Apache24"

# DocumentRoot为网站的源文件存放的目录
DocumentRoot "D:/wamp/www"

# PHP关联Apache, 在httpd.conf 的末尾加上
# php7 support  
LoadModule php7_module "D:/wamp/php-7.2.24-Win32-VC15-x64/php7apache2_4.dll"  
AddHandler application/x-httpd-php .php  
  
# configure thepath to php.ini  
PHPIniDir "D:/wamp/php-7.2.24-Win32-VC15-x64"
```
- 在`D:\wamp\Apache24\bin`目录下，注册Apache服务

```bash
httpd.exe -k install -n httpd
```

## 安装PHP
- 将php.exe所在目录添加系统环境变量PATH，方便全局使用php命令
![微信截图20191030160534.png](https://img.hacpai.com/file/2019/10/微信截图20191030160534-5123a8e2.png)

- 复制php.ini-development重命名为php.ini，修改php.ini中的`extension_dir`路径，需要开启那些扩展根据实际情况。
```powershell
; On windows:
extension_dir = "D:/wamp/php-7.2.23-Win32-VC15-x64/ext"
```

- 在`D:\wnmp\www` 目录下面新建index.php文件，增加`phpinfo();`，测试PHP和Nginx是否关联成功
![微信截图20191031105038.png](https://img.hacpai.com/file/2019/10/微信截图20191031105038-6527e532.png)

## 安装MySQL
- 在`D:\wnmp\mysql-5.7.27-winx64`目录下面创建mysql.ini文件（注：mysql5.7.18之后的版本没有my.ini文件需要手动创建），添加如下内容

```powershell
[client]
port=3306
[mysql]
default-character-set=utf8
[mysqld]
# 端口号
port=3306
# 安装路径
basedir="D:/wamp/mysql-5.7.27-winx64"
# 数据存放路径
# mysql数据没有放到mysql子目录的原因，避免以后升级、卸载mysql导致数据丢失
datadir="D:/wamp/mysqldata"
# 默认字符集
character-set-server=utf8
# 默认存储引擎
default-storage-engine=INNODB
```
- 进入`D:\wamp\mysql-5.7.27-winx64\bin`目录下，打开终端注册MySQL服务

```bash
mysqld -install 
```
- 进入`D:\wamp\mysql-5.7.27-winx64\bin`目录下，初始化MySQL
```bash
mysqld --initialize
```
- 进入`D:\wamp\mysql-5.7.27-winx64\bin`目录下，启动MySQL

```bash
# 启动
net start mysql
# 停止
net stop mysql
```
- `D:\wamp\mysqldata`目录下，打开 **.err** 文件，复制：root@localhost:后的密码(随机密码，每次安装不一样)
![微信截图20191031121951.png](https://img.hacpai.com/file/2019/10/微信截图20191031121951-3d91afe1.png)

- 使用刚才复制的密码登录MySQL

```bash
# 登录MySQL
D:\wamp\mysql-5.7.27-winx64\bin>mysql -u root -p
# 输入刚才复制的密码
Enter password: ************
Welcome to the MySQL monitor.  Commands end with ; or \g.
Your MySQL connection id is 3
Server version: 5.7.27

Copyright (c) 2000, 2019, Oracle and/or its affiliates. All rights reserved.

Oracle is a registered trademark of Oracle Corporation and/or its
affiliates. Other names may be trademarks of their respective
owners.

Type 'help;' or '\h' for help. Type '\c' to clear the current input statement.
mysql> 
```
- 修改MySQL登录密码

```sql
ALTER USER 'root'@'localhost' IDENTIFIED BY 'mysql';
```
- 开启root用户远程连接（任意IP都可以访问）

```sql
UPDATE mysql.user SET Host = '%' WHERE User = 'root';
```

- 最后刷新MySQL的系统权限相关表

```sql
flush privileges;
```
此刻，可以用Navicat连接MySQL了，网络没有问题的情况下，其他机器也可以远程访问你的MySQL

最后 WAMP环境搭建（Win10+Apache+MySQL+PHP）完成了 。

## 一键启动、关闭（MySQL，Apache，PHP） bat
- 下载地址：[https://pan.baidu.com/s/15Bllf_mzOQ8HwsEsd-Alxw](https://pan.baidu.com/s/15Bllf_mzOQ8HwsEsd-Alxw)
