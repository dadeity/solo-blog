title: ' Linux 使用crontab定时备份Mysql数据库'
date: '2019-10-29 17:28:52'
updated: '2019-10-29 17:28:52'
tags: [Linux, MySQL]
permalink: /articles/2019/10/29/1572341332608.html
---
![](https://img.hacpai.com/bing/20190311.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)

 ## 前言
 > 项目要部署到开发环境，为了保证客户机房断电或者其他原因导致数据库数据丢失问题，最好的办法就是**及时备份数据库**
 > 如果是手动去备份的话！那想想就好了，如果真的去做，你得去抓狂
 > 那有什么好的办法呢？
 > 这时 `Linux`的自动定时任务命令`crontab`就发挥他的作用了
## 定时备份MySQL数据库教程
1. 在`/home/dduan`目录下面新建`dbbackup.sh`文件并且添加`x`执行权限

```shell
dduan@dduan:~$ sudo su
[sudo] password for dduan:
root@dduan:/home/dduan# touch dbbackup.sh
root@dduan:/home/dduan# chmod a+x dbbackup.sh
root@dduan:/home/dduan# ls -al dbbackup.sh
-rw-rw-rw- 1 root root 0 May 30 06:37 dbbackup.sh
```
2. 使用`vim`编辑器编写`dbbackup.sh`文件内容

```shell
#!/bin/bash
# 备份文件地址
backupdir="/home/dduan"

# 备份文件后缀时间
time=`date +%Y_%m_%d_%H_%M_%S`

# 需要备份的数据库名称
db_name="monitor1"

# f文件名
db_file_name="${backupdir}/${db_name}${time}.sql.gz"

# mysql 用户名
# db_user = root

# mysql 密码
# db_password = mysql

# mysqldump 命令使用绝对路径
# mysqldump ${db_name} | gzip > ${backupdir}/${db_name}${time}.sql.gz 
mysqldump ${db_name} | gzip > ${db_file_name}

#echo "导出数据库文件" ${db_file_name}

# 删除7天之前的备份文件
# find $backupdir -name $db_name"*.sql.gz" -type f -mtime +7 -exec rm -rf {} \; > /dev/null 2 >&1
```
3. 为了避免MySQL 用户名和密码暴露，需要在MySQL配置文件中添加用户名和密码，例如：Ubuntu在`/etc/mysql/conf.d/mysqldump.cnf`文件填写如下

```shell
root@dduan:/home/dduan# vi /etc/mysql/conf.d/mysqldump.cnf
[mysqldump]
quick
quote-names
max_allowed_packet      = 16M
# MySQL用户名
user=root
# MySQL密码
password=mysql
```
4. 使用`crontab`创建定时任务
为了更加明白添加定时任务是 5个`*`的作用，特附图一张，所谓“英雄不问出处，所以此图来历...”
![在这里插入图片描述](https://img-blog.csdnimg.cn/20190530145732532.png?x-oss-process=image/watermark,type_ZmFuZ3poZW5naGVpdGk,shadow_10,text_aHR0cHM6Ly9ibG9nLmNzZG4ubmV0L2dpdGh1Yl8zODMzNjkyNA==,size_16,color_FFFFFF,t_70)

**在以上各个字段中，还可以使用以下特殊字符：**
- 星号（*）：代表所有可能的值，例如month字段如果是星号，则表示在满足其它字段的制约条件后每月都执行该命令操作。
- 逗号（,）：可以用逗号隔开的值指定一个列表范围，例如，“1,2,5,7,8,9”
- 中杠（-）：可以用整数之间的中杠表示一个整数范围，例如“2-6”表示“2,3,4,5,6”
- 正斜线（/）：可以用正斜线指定时间的间隔频率，例如“0-23/2”表示每两小时执行一次。同时正斜线可以和星号一起使用，例如*/10，如果用在minute字段，表示每十分钟执行一次。

执行`crontab -e`添加`* * * * * /home/dduan/dbbackup.sh`命令，意思是每分钟备份一次数据库，可以根据实际情况自己设置设备时间
```shell
root@dduan:/home/dduan# root@dduan:/home/dduan# crontab -e
no crontab for root - using an empty one

Select an editor.  To change later, run 'select-editor'.
  1. /bin/nano        <---- easiest
  2. /usr/bin/vim.basic
  3. /usr/bin/vim.tiny
  4. /bin/ed

Choose 1-4 [1]: * * * * * /home/dduan/dbbackup.sh
```
5.  重启定时任务

```shell
root@dduan:/home/dduan# systemctl restart cron
```

