title: 'Error:java: 无效的标记: --release'
date: '2019-10-29 15:56:14'
updated: '2019-10-30 13:41:36'
tags: [Java, IDEA]
permalink: /articles/2019/10/29/1572335774463.html
---
![](https://img.hacpai.com/bing/20180522.jpg?imageView2/1/w/960/h/540/interlace/1/q/100) 

## 问题描述
![20181009092120622.png](https://img.hacpai.com/file/2019/10/20181009092120622-ef16a94e.png)

**以上错误是因为Java版本不匹配**
## 解决办法
- 需要修改是一下三处：

```
file -> settings -> Build Execution and Deployment -> Java -> Compiler
```

```
 File -> Project Structure -> Module Settings -> Tab: Source: Language Level
```

```
 File -> Project Structure -> Project(In left pane) -> Project language level
```

