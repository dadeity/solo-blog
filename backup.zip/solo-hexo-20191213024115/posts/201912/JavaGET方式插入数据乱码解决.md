title: Java GET方式插入数据乱码解决
date: '2019-12-12 12:45:39'
updated: '2019-12-12 12:45:39'
tags: [Java, Tomcat]
permalink: /articles/2019/12/12/1576125939103.html
---
![](https://img.hacpai.com/bing/20190704.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)

# 环境配置
- JDK版本：1.7
- OS版本：Win10
- Tomcat版本：7.0
# 问题描述
- 使用GET方式URL+参数插入数据
![微信截图20191212123343.png](https://img.hacpai.com/file/2019/12/微信截图20191212123343-0f224adf.png)

- 数据库出现乱码
![微信截图20191212122318.png](https://img.hacpai.com/file/2019/12/微信截图20191212122318-29549687.png)

# 解决办法
- Tomcat配置文件，`server.xml`设置`URIEncoding="UTF-8"`
![微信截图20191212123856.png](https://img.hacpai.com/file/2019/12/微信截图20191212123856-5b689fec.png)

- MySQL编码方式与Tomcat保持一致
	```bash
	[client]
	port=3306
	default-character-set=utf8
	[mysql]
	default-character-set=utf8
	[mysqld]
	# 端口号
	port=3306
	# 安装路径
	basedir="D:/wamp/mysql-5.7.27-winx64"
	# 数据存放路径
	# mysql数据没有放到mysql子目录的原因，避免以后升级、卸载mysql导致数据丢失
	datadir="D:/wamp/mysqldata"
	# 默认字符集
	character-set-server=utf8
	# 默认存储引擎
	default-storage-engine=INNODB
	```
## 如果上面的设置没有问题，依然乱码
- 在**index.jsp**文件头部加入`<%@ page language="java"  contentType="text/html; charset=UTF-8" %>`
