title: '''build.plugins.plugin.version'' for org.apache.maven.plugins:maven-compiler-plugin
  is missing.解决'
date: '2019-11-29 15:49:49'
updated: '2019-11-29 15:49:49'
tags: [Maven, IDEA, Java]
permalink: /articles/2019/11/29/1575013789495.html
---
![](https://img.hacpai.com/bing/20171120.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)

# 报错信息

```shell
[WARNING] 
[WARNING] Some problems were encountered while building the effective model for com:mmall:war:1.0-SNAPSHOT
[WARNING] 'build.plugins.plugin.version' for org.apache.maven.plugins:maven-compiler-plugin is missing. @ line 263, column 21
[WARNING] 
[WARNING] It is highly recommended to fix these problems because they threaten the stability of your build.
[WARNING] 
[WARNING] For this reason, future Maven versions might no longer support building such malformed projects.
[WARNING] 
```
# 原因 
没有设置 `maven-compiler-plugin` 版本
# 解决办法
- 在pom.xml 文件中，找到 `maven-compiler-plugin`设置版本

```xml
<plugin>
	<groupId>org.apache.maven.plugins</groupId>
    <artifactId>maven-compiler-plugin</artifactId>
    <!-- 设置版本号 -->
    <version>2.3.2</version>
    <configuration>
    	<source>1.8</source>
        <target>1.8</target>
        <encoding>UTF-8</encoding>
   	</configuration>
</plugin>
```

