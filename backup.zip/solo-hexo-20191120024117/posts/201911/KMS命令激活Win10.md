title: KMS命令激活 Win10
date: '2019-11-18 11:01:56'
updated: '2019-11-18 11:02:57'
tags: [Win10]
permalink: /articles/2019/11/18/1574046116713.html
---
![](https://img.hacpai.com/bing/20190720.jpg?imageView2/1/w/960/h/540/interlace/1/q/100) 

# KMS 命令激活

> KMS激活都是**180**天，到期继续执行下面操作步骤续期即可：
## 操作步骤
- 右键点击开始图标，弹出这个菜单，选择【windows powershell(管理员)】，或者命令提示符管理员
![微信截图20191118105208.png](https://img.hacpai.com/file/2019/11/微信截图20191118105208-f7474edb.png)
- 打开命令窗口，复制这个命令`slmgr /ipk W269N-WFGWX-YVC9B-4J6C9-T83GX`，在命令窗口鼠标右键会自动粘贴，按回车执行
- 复制命令`slmgr /skms zh.us.to`，在窗口中右键自动粘贴，按回车执行
![微信截图20191118103947.png](https://img.hacpai.com/file/2019/11/微信截图20191118103947-1935f729.png)
- 复制命令slmgr /ato，在窗口总右键自动粘贴，按回车执行激活操作，提示成功地激活了产品
![微信截图20191118104110.png](https://img.hacpai.com/file/2019/11/微信截图20191118104110-be66eb1e.png)

