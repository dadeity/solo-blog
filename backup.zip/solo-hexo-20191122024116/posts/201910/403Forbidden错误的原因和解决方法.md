title: 403 Forbidden错误的原因和解决方法
date: '2019-10-29 16:24:24'
updated: '2019-10-30 13:53:14'
tags: [HTTPS]
permalink: /articles/2019/10/29/1572337464401.html
---
![](https://img.hacpai.com/bing/20190321.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)

## 前言
>在访问网站的时候，会时不时的出现`403 Forbidden`错误，浏览器会给出`403 Forbidden`错误提示，在打开`Access Error`中列出的URL之后, 出现以下错误：
>
> `403 Forbidden
Access to this resource on the server is denied!
Powered By LiteSpeed Web Server
LiteSpeed Technologies is not responsible for administration and contents of this web site!`
>
![20180912112524111.png](https://img.hacpai.com/file/2019/10/20180912112524111-0b510809.png)

>
`403`错误是网站访问过程中，常见的错误提示。资源不可用，服务器理解客户的请求，但拒绝处理它。通常由于服务器上文件或目录的权限设置导致，比如`IIS`或者`Apache`设置了访问权限不当。一般会出现以下提示

## 1、403 forbidden是什么意思？

`403 Forbidden`是HTTP协议中的一个状态码(Status Code)。可以简单的理解为没有权限访问此站。该状态表示服务器理解了本次请求但是拒绝执行该任务，该请求不该重发给服务器。在HTTP请求的方法不是“HEAD”，并且服务器想让客户端知道为什么没有权限的情况下，服务器应该在返回的信息中描述拒绝的理由。在服务器不想提供任何反馈信息的情况下，服务器可以用404 Not Found代替403 Forbidden。
## 2、403错误代码的分类介绍
 
- 403.1
`403.1`错误是由于"执行"访问被禁止而造成的，若试图从目录中执行`CGI`、`ISAPI`或其他可执行程序，但该目录不允许执行程序时便会出现此种错误。

- 403.2
`403.2`错误是由于"读取"访问被禁止而造成的。导致此错误是由于没有可用的默认网页并且没有对目录启用目录浏览，或者要显示的HTML网页所驻留的目录仅标记为"可执行"或"脚本"权限。

- 403.3
`403.3`错误是由于"写入"访问被禁止而造成的，当试图将文件上载到目录或在目录中修改文件，但该目录不允许"写"访问时就会出现此种错误。

- 403.4
`403.4`错误是由于要求`SSL`而造成的，您必须在要查看的网页的地址中使用"`https`"。

- 403.5
`403.5`错误是由于要求使用128位加密算法的Web浏览器而造成的，如果您的浏览器不支持128位加密算法就会出现这个错误，您可以连接微软网站进行浏览器升级。

- 403.6
`403.6`错误是由于`IP`地址被拒绝而造成的。如果服务器中有不能访问该站点的`IP`地址列表，并且您使用的`IP`地址在该列表中时您就会返回这条错误信息。

- 403.7
`403.7`错误是因为要求客户证书，当需要访问的资源要求浏览器拥有服务器能够识别的安全套接字层(SSL) 客户证书时会返回此种错误。

- 403.8
`403.8`错误是由于禁止站点访问而造成的，若服务器中有不能访问该站点的DNS名称列表，而您使用的DNS名称在列表中时就会返回此种信息。请注意区别403.6与403.8错误。

- 403.9
`403.9`错误是由于连接的用户过多而造成的，由于Web服务器很忙，因通讯量过多而无法处理请求时便会返回这条错误。

- 403.10
`403.10`错误是由于无效配置而导致的错误，当您试图从目录中执行CGI、ISAPI或其他可执行程序，但该目录不允许执行程序时便会返回这条错误。

- 403.11
`403.11`错误是由于密码更改而导致无权查看页面。

- 403.12
`403.12`错误是由于映射器拒绝访问而造成的。若要查看的网页要求使用有效的客户证书，而您的客户证书映射没有权限访问该Web站点时就会返回映射器拒绝访问的错误。

- 403.13
`403.13`错误是由于需要查看的网页要求使用有效的客户证书而使用的客户证书已经被吊销，或者无法确定证书是否已吊销造成的。

- 403.14
`403.14`错误Web 服务器被配置为不列出此目录的内容，拒绝目录列表。

- 403.15
`403.15`错误是由于客户访问许可过多而造成的，当服务器超出其客户访问许可限制时会返回此条错误。

- 403.16
`403.16`错误是由于客户证书不可信或者无效而造成的。

- 403.17
`403.17`错误是由于客户证书已经到期或者尚未生效而造成的。

## 3、导致403错误的主要原因

- 你的IP被列入黑名单。

- 你在一定时间内过多地访问此网站（一般是用采集程序），被防火墙拒绝访问了。

- 网站域名解析到了空间，但空间未绑定此域名。

- 你的网页脚本文件在当前目录下没有执行权限。

- 在不允许写/创建文件的目录中执行了创建/写文件操作。

- 以http方式访问需要ssl连接的网址。

- 浏览器不支持SSL 128时访问SSL 128的连接。

- 在身份验证的过程中输入了错误的密码。

- DNS解析错误，手动更改DNS服务器地址。

- 连接的用户过多，可以过后再试。

- 服务器繁忙，同一IP地址发送请求过多，遭到服务器智能屏蔽。

## 4、解决403 forbidden错误的方法
#### 4.1、重建`DNS`缓存

- 对于一些常规的`403 forbidden`错误，马海祥建议大家首先要尝试的就是重建`dns`缓存，在运行中输入`cmd`，然后输入`ipconfig /flushdns`即可。

- 如果不行的话，就需要在hosts文件里把主页解析一下了。

- 同时，查看是否在网站虚拟目录中添加默认文档，一般默认文档为：`index.html；index.asp；index.php；index.jsp；default.htm；default.asp`等
#### 4.2、修改文件夹安全属性

- 用以下命令修改文件夹安全属性
```
chcon -R -t httpd_user_content_t public_html/
```
- 所用命令解析：

```
ls -Z -d public_html/

# 显示文件／目录的安全语境－Z, –context
Display security context so it fits on most displays. Displays only mode, user, group, security context and file name.-d, –directory
list directory entries instead of contents, and do not dereference symbolic links
chcon -R -t httpd_user_content_t public_html/

＃ 修改文件／目录的安全语境-R, –recursive
change files and directories recursively-t, –type
set type TYPE in the target security context
```

#### 4.3、关于`apache`导致的`403 forbidden`错误的解决办法

- 打开`apache`的配置文件`httpd.conf`，找到这段代码：

```
Options FollowSymLinks
AllowOverride None
Order deny,allow
Deny from all
```
- 有时候由于配置了`php`后，这里的`Deny from all`已经拒绝了一切连接。把该行改成`allow from all`，修改后的代码如下，问题解决。

```
Options FollowSymLinks
AllowOverride None
Order deny,allow
Allow from all
```

**之所以会出现错误，是因为大多数的国外主机在配置`Apache`的时候启用了`mod_security`，也就是开启了安全检查，如果提交的信息中包含`select , % , bin`等关键字，`Apache`就会禁止，并给出`403，404，500`等错误**

#### 4.4、关于`HawkHost`空间出现`403 Forbidden`错误的解决方法

*有的时候在共享服务器上安装了`Mod security`，当网址包含有`%`号等其它敏感字符时，就会被`Mod security`阻止，马海祥博客曾经也出现过此情况。*

- 解决HawkHost 403 Forbidden 错误的方法：
**在`.htaccess`文件里添加如下代码：**
```
SecFilterEngine Off
SecFilterScanPOST Off
```
**直接放在网站的根目录或者程序运行的目录下**

#### 4.5、关于`WordPress`导致的`403 Forbidden`错误解决方法

- 对于一些使用WordPress管理程序搭建的博客来说，就需要修改`.htaccess`文件，在后面添加上如下内容即可，其实就是`disable mod_security`

```
SecFilterEngine Off
SecFilterScanPOST Off
```
**另外`dedecms`的可能还需要再加一条，以让默认访问的是`index.html`文件的`DirectoryIndex index.html`，修改`.htaccess`文件，将文件上传之后，再重新打开之前出现`403 Forbidden的URL`就没有再出现错误，直接可以打开了**

> 马海祥博客点评：
> 从SEO的角度来说，常见403返回码的含义是“forbidden”，搜索引擎会认为当前页面禁止访问，但也不会删除，短期内会反复访问几次，如果网页允许访问，则正常抓取；如果长期返回403，搜索引擎会认为该URL是失效链接，将会删除。因此，马海祥建议大家一旦发现自己的网站出现403错误的话，一定要及时的修复，使其链接能够正常访问。如果是不需要的页面，应该设置返回404状态码，按404操作。

