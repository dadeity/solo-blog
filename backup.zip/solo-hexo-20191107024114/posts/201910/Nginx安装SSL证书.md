title: Nginx 安装 SSL证书
date: '2019-10-29 15:36:06'
updated: '2019-10-29 16:10:23'
tags: [Nginx, HTTPS, SSL]
permalink: /articles/2019/10/29/1572334566925.html
---
![](https://img.hacpai.com/bing/20190929.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)

# 1. 申请SSL证书
## 1.1 证书申请流程（阿里云）
![在这里插入图片描述](https://img-blog.csdnimg.cn/2019102914504774.png)
## 1.2 下载证书
在证书控制台下载Nginx版本证书，下载到本地的压缩文件包解压后包含：
- crt文件：是证书文件，crt是pem文件的扩展名。
- key文件：证书的私钥文件（申请证书时如果没有选择自动创建CSR，则没有该文件）。
![在这里插入图片描述](https://img-blog.csdnimg.cn/20191029151319502.png?x-oss-process=image/watermark,type_ZmFuZ3poZW5naGVpdGk,shadow_10,text_aHR0cHM6Ly9ibG9nLmNzZG4ubmV0L2dpdGh1Yl8zODMzNjkyNA==,size_16,color_FFFFFF,t_70)
**友情提示**： .pem扩展名的证书文件采用Base64-encoded的PEM格式文本文件，可根据需要修改扩展名。
# 2. Nginx服务器安装SSL证书
## 2.1 上传证书到服务器指定目录
在服务器新建文件夹ssl，并且把证书 **.pem** 与 **.key** 上传到该目录下，例如：我上传到`/etc/nginx/ssl`目录下面
## 2.2 修改nginx.conf配置
- 打开 Nginx 安装目录下 conf 目录中的 nginx.conf 文件，找到：

```powershell
# HTTPS server
# #server {
# listen 443;
# server_name localhost;
# ssl on;
# ssl_certificate cert.pem;
# ssl_certificate_key cert.key;
# ssl_session_timeout 5m;
# ssl_protocols SSLv2 SSLv3 TLSv1;
# ssl_ciphers ALL:!ADH:!EXPORT56:RC4+RSA:+HIGH:+MEDIUM:+LOW:+SSLv2:+EXP;
# ssl_prefer_server_ciphers on;
# location / {
#
#
#}
#}
```
- 将其修改为 (以下属性中ssl开头的属性与证书配置有直接关系，其它属性请结合自己的实际情况复制或调整) :

```powershell
server {
 listen 443;
 server_name localhost;
 ssl on;
 root html;
 index index.html index.htm;
 ssl_certificate   cert/a.pem;
 ssl_certificate_key  cert/a.key;
 ssl_session_timeout 5m;
 ssl_ciphers ECDHE-RSA-AES128-GCM-SHA256:ECDHE:ECDH:AES:HIGH:!NULL:!aNULL:!MD5:!ADH:!RC4;
 ssl_protocols TLSv1 TLSv1.1 TLSv1.2;
 ssl_prefer_server_ciphers on;
 location / {
     root html;
     index index.html index.htm;
 }
}
```
重启nginx服务
# 3. 添加安全组规则（很重要！）
云服务器默认在入方向规则里面没有443端口，安装ssl证书，http>https，https为443端口，需要添加规则

- 添加规则
![在这里插入图片描述](https://img-blog.csdnimg.cn/20191029153148327.png?x-oss-process=image/watermark,type_ZmFuZ3poZW5naGVpdGk,shadow_10,text_aHR0cHM6Ly9ibG9nLmNzZG4ubmV0L2dpdGh1Yl8zODMzNjkyNA==,size_16,color_FFFFFF,t_70)
# 4. 验证，浏览器输入网址
![在这里插入图片描述](https://img-blog.csdnimg.cn/20191029153310188.png?x-oss-process=image/watermark,type_ZmFuZ3poZW5naGVpdGk,shadow_10,text_aHR0cHM6Ly9ibG9nLmNzZG4ubmV0L2dpdGh1Yl8zODMzNjkyNA==,size_16,color_FFFFFF,t_70)
