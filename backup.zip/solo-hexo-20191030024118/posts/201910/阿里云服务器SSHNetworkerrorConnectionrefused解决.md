title: '阿里云服务器SSH：Network error: Connection refused解决'
date: '2019-10-29 17:06:04'
updated: '2019-10-29 17:06:04'
tags: [SSL]
permalink: /articles/2019/10/29/1572339964561.html
---
![](https://img.hacpai.com/bing/20180617.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)

> ## 问题描述
> 今天使用`ssh`工具远程连接阿里云服务器提示`Network error: Connection refused`
> ## 问题原因
> 云服务器默认是开启`22`端口的，不能访问原因是安全组规则没有被允许
## 解决办法
- 登录云服务管理控制台，依次进入 `云服务器 ECS`-`网络和安装`-`安全组`-`配置规则`
![在这里插入图片描述](https://img-blog.csdn.net/20180929113551530?watermark/2/text/aHR0cHM6Ly9ibG9nLmNzZG4ubmV0L2dpdGh1Yl8zODMzNjkyNA==/font/5a6L5L2T/fontsize/400/fill/I0JBQkFCMA==/dissolve/70)
- 点击`添加安全组规则`
![在这里插入图片描述](https://img-blog.csdn.net/20180929113735492?watermark/2/text/aHR0cHM6Ly9ibG9nLmNzZG4ubmV0L2dpdGh1Yl8zODMzNjkyNA==/font/5a6L5L2T/fontsize/400/fill/I0JBQkFCMA==/dissolve/70)

- 点击确定，使用ssh工具连接即可
