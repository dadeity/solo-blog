title: 'Error:java: 无效的标记: --release'
date: '2019-10-29 15:56:14'
updated: '2019-10-29 15:56:42'
tags: [Java, IDEA]
permalink: /articles/2019/10/29/1572335774463.html
---
![](https://img.hacpai.com/bing/20180522.jpg?imageView2/1/w/960/h/540/interlace/1/q/100) 

## 问题描述
![在这里插入图片描述](https://img-blog.csdn.net/20181009092120622?watermark/2/text/aHR0cHM6Ly9ibG9nLmNzZG4ubmV0L2dpdGh1Yl8zODMzNjkyNA==/font/5a6L5L2T/fontsize/400/fill/I0JBQkFCMA==/dissolve/70)
**以上错误是因为Java版本不匹配**
## 解决办法
- 需要修改是一下三处：

```
file -> settings -> Build Execution and Deployment -> Java -> Compiler
```

```
 File -> Project Structure -> Module Settings -> Tab: Source: Language Level
```

```
 File -> Project Structure -> Project(In left pane) -> Project language level
```

