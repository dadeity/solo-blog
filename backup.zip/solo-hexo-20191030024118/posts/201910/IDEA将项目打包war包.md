title: IDEA 将项目打包war包
date: '2019-10-29 16:18:01'
updated: '2019-10-29 16:20:34'
tags: [Java, 后端, IDEA]
permalink: /articles/2019/10/29/1572337081577.html
---
![](https://img.hacpai.com/bing/20191011.jpg?imageView2/1/w/960/h/540/interlace/1/q/100) 

## 1、准备工作

- `IntelliJ IDEA`开发工具
- 可以正常运行的`Java`项目

## 2、打包`war`包流程

- 使用快捷键`Ctrl+Alt+Shift+s` 或者 鼠标点击选中项目名按`F4` 打开 `Project Structure`界面
![这里写图片描述](https://img-blog.csdn.net/20180905122204165?watermark/2/text/aHR0cHM6Ly9ibG9nLmNzZG4ubmV0L2dpdGh1Yl8zODMzNjkyNA==/font/5a6L5L2T/fontsize/400/fill/I0JBQkFCMA==/dissolve/70)

- 选择`Artifacts`，点击右边`+`,依次选择`Web Application:Archive` 和 `For 'myPro:war exploded'` 
![这里写图片描述](https://img-blog.csdn.net/20180905122532372?watermark/2/text/aHR0cHM6Ly9ibG9nLmNzZG4ubmV0L2dpdGh1Yl8zODMzNjkyNA==/font/5a6L5L2T/fontsize/400/fill/I0JBQkFCMA==/dissolve/70)

- [修改名称：可选] 和 注意 `war`输出的路径
![这里写图片描述](https://img-blog.csdn.net/20180905123252443?watermark/2/text/aHR0cHM6Ly9ibG9nLmNzZG4ubmV0L2dpdGh1Yl8zODMzNjkyNA==/font/5a6L5L2T/fontsize/400/fill/I0JBQkFCMA==/dissolve/70)

- 点击下图`红色箭头`所指`+`图标，选择`Directory Content`,添加你的`WebRoot`目录，然后点击`OK` 

![这里写图片描述](https://img-blog.csdn.net/20180905123728655?watermark/2/text/aHR0cHM6Ly9ibG9nLmNzZG4ubmV0L2dpdGh1Yl8zODMzNjkyNA==/font/5a6L5L2T/fontsize/400/fill/I0JBQkFCMA==/dissolve/70)

- 在主界面选择`Build` -- `Build Artifacts`，找到刚才需要打包的项目名点击`build`
![这里写图片描述](https://img-blog.csdn.net/20180905140139212?watermark/2/text/aHR0cHM6Ly9ibG9nLmNzZG4ubmV0L2dpdGh1Yl8zODMzNjkyNA==/font/5a6L5L2T/fontsize/400/fill/I0JBQkFCMA==/dissolve/70)
