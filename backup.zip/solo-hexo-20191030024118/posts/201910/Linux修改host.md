title: Linux 修改 host
date: '2019-10-29 17:00:33'
updated: '2019-10-29 17:00:33'
tags: [Linux]
permalink: /articles/2019/10/29/1572339633560.html
---
![](https://img.hacpai.com/bing/20190322.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)

> ## 为什么要修改`host`
> - `/etc/hosts`文件存放的是 **域名** 与 **IP** 的对应关系
> - 就我开发人员来说，内测的时候，我们通常会去修改host文件，将线上的域名，绑定成本地IP

## 修改`host`
- 使用`vi  /etc/hosts`命令打开文件，在文件中添加`IP + 对应的域名`
![在这里插入图片描述](https://img-blog.csdn.net/20180918153502941?watermark/2/text/aHR0cHM6Ly9ibG9nLmNzZG4ubmV0L2dpdGh1Yl8zODMzNjkyNA==/font/5a6L5L2T/fontsize/400/fill/I0JBQkFCMA==/dissolve/70)
- 保存退出`host`文件，重启系统，执行以下命令
```shell
ping www.dd.com	
```
![在这里插入图片描述](https://img-blog.csdn.net/20180918153739862?watermark/2/text/aHR0cHM6Ly9ibG9nLmNzZG4ubmV0L2dpdGh1Yl8zODMzNjkyNA==/font/5a6L5L2T/fontsize/400/fill/I0JBQkFCMA==/dissolve/70)

**发现 `www.dd.com` 已经指向本地`127.0.0.1`**
 
