title: 'ERROR 1133 (42000): Can''t find any matching row in the user table'
date: '2019-10-29 16:35:00'
updated: '2019-10-29 16:35:00'
tags: [MySQL]
permalink: /articles/2019/10/29/1572338100582.html
---
![](https://img.hacpai.com/bing/20181105.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)

## 1、问题描述

> 使用`set password for 'root'@'localhost'=password('MyNewPass4!');` 命令修改`mysql`数据库`root`用户密码提示**`ERROR 1133 (42000): Can't find any matching row in the user table`**错误

## 2、主要原因

- 错误提示的字面意思：`在用户表中找不到任何匹配的行`

- 登录`mysql`执行以下命令

```sql
use mysql;
select Host,User from user;
```
![这里写图片描述](https://img-blog.csdn.net/20180914140052746?watermark/2/text/aHR0cHM6Ly9ibG9nLmNzZG4ubmV0L2dpdGh1Yl8zODMzNjkyNA==/font/5a6L5L2T/fontsize/400/fill/I0JBQkFCMA==/dissolve/70)

**主要原因是修改密码的`条件不否`**
## 3、解决办法

- 将`set password for 'root'@'localhost'=password('MyNewPass4!');` 代码中的`localhost`修改`%`，与数据库`Host`字段值一致

```sql
set password for 'root'@'%'=password('MyNewPass4!');
```

- 刷新

```sql
flush privileges;
```
![这里写图片描述](https://img-blog.csdn.net/20180914140632391?watermark/2/text/aHR0cHM6Ly9ibG9nLmNzZG4ubmV0L2dpdGh1Yl8zODMzNjkyNA==/font/5a6L5L2T/fontsize/400/fill/I0JBQkFCMA==/dissolve/70)
