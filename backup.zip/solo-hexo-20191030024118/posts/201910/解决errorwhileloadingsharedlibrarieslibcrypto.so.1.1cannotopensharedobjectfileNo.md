title: '解决：error while loading shared libraries: libcrypto.so.1.1: cannot open shared
  object file: No'
date: '2019-10-29 16:26:52'
updated: '2019-10-29 16:26:52'
tags: [OpenSSL, Linux]
permalink: /articles/2019/10/29/1572337612868.html
---
![](https://img.hacpai.com/bing/20180616.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)

## 1、问题

> - 源码安装完`OpenSSL`后，执行`openssl version`命令
> - 启动`web`服务器的时候，如`nginx`
> - **以上操作后可能会出现`error while loading shared libraries: libcrypto.so.1.1: cannot open shared object file: No`**

## 2、原因

- 执行`ldd + 程序、可执行文件的绝对路径`命令，你就会发现，`是因为找不到库的位置造成的`

```shell
ldd /usr/local/openssl/bin/openssl
```
![这里写图片描述](https://img-blog.csdn.net/20180913173837161?watermark/2/text/aHR0cHM6Ly9ibG9nLmNzZG4ubmV0L2dpdGh1Yl8zODMzNjkyNA==/font/5a6L5L2T/fontsize/400/fill/I0JBQkFCMA==/dissolve/70)

## 3、解决办法

- 使用`root`用户操作

```shell
ln -s /usr/local/lib/libssl.so.1.1 /usr/lib/libssl.so.1.1
ln -s /usr/local/lib/libcrypto.so.1.1 /usr/lib/libcrypto.so.1.1
```
