title: CentOS 7 yum 安装与配置 JDK
date: '2019-10-29 16:19:33'
updated: '2019-10-29 16:20:20'
tags: [JDK, CentOS, Linux]
permalink: /articles/2019/10/29/1572337173571.html
---
![](https://img.hacpai.com/bing/20181106.jpg?imageView2/1/w/960/h/540/interlace/1/q/100) 

## 1、检查是否已安装`JDK`及卸载

 - 以下命令二选一，中括号选一即可
```shell
yum list installed | grep [java][jdk]
rpm -qa | grep [java][jdk][gcj]
```
![这里写图片描述](https://img-blog.csdn.net/20180830140522349?watermark/2/text/aHR0cHM6Ly9ibG9nLmNzZG4ubmV0L2dpdGh1Yl8zODMzNjkyNA==/font/5a6L5L2T/fontsize/400/fill/I0JBQkFCMA==/dissolve/70)
`执行命令出现如上图所示，需要卸载，反之即不用`

 - 卸载`JAVA`环境
```shell
yum -y remove java-1.6.0-openjdk*  //表时卸载所有openjdk相关文件输入
yum -y remove tzdata-java.noarch   //卸载tzdata-java
```
## 2、安装`JDK`
- 查看`JDK`软件包列表

```shell
yum search java | grep -i --color jdk
```
![这里写图片描述](https://img-blog.csdn.net/20180830142000615?watermark/2/text/aHR0cHM6Ly9ibG9nLmNzZG4ubmV0L2dpdGh1Yl8zODMzNjkyNA==/font/5a6L5L2T/fontsize/400/fill/I0JBQkFCMA==/dissolve/70)

- 选择版本安装

```shell
yum install -y java-1.8.0-openjdk java-1.8.0-openjdk-devel
#或者如下命令，安装jdk1.8.0的所有文件
yum install -y java-1.8.0-openjdk*

```
- 查看`JDK`是否安装成功
```shell
java -version
```
![这里写图片描述](https://img-blog.csdn.net/20180830142627822?watermark/2/text/aHR0cHM6Ly9ibG9nLmNzZG4ubmV0L2dpdGh1Yl8zODMzNjkyNA==/font/5a6L5L2T/fontsize/400/fill/I0JBQkFCMA==/dissolve/70)
## 3、配置环境变量
-  `JDK`默认安装路径`/usr/lib/jvm`
![这里写图片描述](https://img-blog.csdn.net/20180830143829503?watermark/2/text/aHR0cHM6Ly9ibG9nLmNzZG4ubmV0L2dpdGh1Yl8zODMzNjkyNA==/font/5a6L5L2T/fontsize/400/fill/I0JBQkFCMA==/dissolve/70)
- 在`/etc/profile`文件添加如下命令

```

# set java environment  
JAVA_HOME=/usr/lib/jvm/java-1.8.0-openjdk-1.8.0.181-3.b13.el7_5.x86_64
PATH=$PATH:$JAVA_HOME/bin  
CLASSPATH=.:$JAVA_HOME/lib/dt.jar:$JAVA_HOME/lib/tools.jar  
export JAVA_HOME  CLASSPATH  PATH 
```
- 保存关闭`profile`文件，执行如下命令生效

```shell
source  /etc/profile
```
- 使用如下命令，查看`JDK`变量
```shell
 echo $JAVA_HOME
 echo $PATH
 echo $CLASSPATH
```
![这里写图片描述](https://img-blog.csdn.net/20180830144605853?watermark/2/text/aHR0cHM6Ly9ibG9nLmNzZG4ubmV0L2dpdGh1Yl8zODMzNjkyNA==/font/5a6L5L2T/fontsize/400/fill/I0JBQkFCMA==/dissolve/70)
